
//#include <iostream>
//#include <conio.h>
//#include "Game.h"
//#include "Foundation.h"
//#include "Game.h"
//#include "utility.h"
//
//











//
//bool Game::moveCardBetweenTableau(int fromPile, int toPile) {
//    // Validate pile indices
//    if (fromPile < 0 || fromPile >= tableau.size() || toPile < 0 || toPile >= tableau.size()) {
//        return false;  // Invalid pile indices
//    }
//
//    // Check if there are cards to move from the source pile
//    if (tableau[fromPile].empty()) {
//        return false;  // No cards to move
//    }
//
//    // Find the first face-up card in the source pile
//    int firstFaceUpIndex = -1;
//    for (int i = 0; i < tableau[fromPile].size(); ++i) {
//        if (tableau[fromPile][i].isFaceUp()) {
//            firstFaceUpIndex = i;
//            break;
//        }
//    }
//
//    if (firstFaceUpIndex == -1) {
//        return false;  // No face-up cards to move
//    }
//
//    // Check if the move is valid
//    Card& cardToMove = tableau[fromPile][firstFaceUpIndex];
//
//    // Check if the target pile is empty
//    if (tableau[toPile].empty()) {
//        if (cardToMove.getRank() == Rank::King) {
//            // Move all face-up cards from the source pile to the target pile
//            tableau[toPile].insert(tableau[toPile].end(), tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());
//            tableau[fromPile].erase(tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());
//
//            flipTopCardInTableau(fromPile);  // Flip the top card in the source pile, if needed
//
//            // Track the move in moveHistory
//            moveHistory.push({ fromPile, toPile });
//
//            // Clear the redoStack when a new move is made
//            while (!redoStack.empty()) {
//                redoStack.pop();
//            }
//
//            updateScore(10);  // Update score for a successful move
//            return true;
//        }
//        else {
//            return false;  // Only a King can be moved to an empty pile
//        }
//    }
//    else {
//        // Get the top card of the target pile
//        Card& topCard = tableau[toPile].back();
//
//        // Check if the move is valid for alternating color and one rank lower
//        if (cardToMove.isAlternatingColor(topCard) && cardToMove.isOneRankLower(topCard)) {
//            // Move all face-up cards from the source pile to the target pile
//            tableau[toPile].insert(tableau[toPile].end(), tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());
//            tableau[fromPile].erase(tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());
//
//            flipTopCardInTableau(fromPile);  // Flip the top card in the source pile, if needed
//
//            // Track the move in moveHistory
//            moveHistory.push({ fromPile, toPile });
//
//            // Clear the redoStack when a new move is made
//            while (!redoStack.empty()) {
//                redoStack.pop();
//            }
//
//            updateScore(10);  // Update score for a successful move
//            return true;
//        }
//    }
//
//    return false;  // Move not successful
//}
