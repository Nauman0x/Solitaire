#include "Deck.h"
#include <random>
#include "Deck.h"
#include <random>


Deck::Deck() {
    for (int suit = static_cast<int>(Suit::Hearts); suit <= static_cast<int>(Suit::Spades); ++suit) {
        for (int rank = static_cast<int>(Rank::Ace); rank <= static_cast<int>(Rank::King); ++rank) {
            Card newCard(static_cast<Rank>(rank), static_cast<Suit>(suit));
            cards.push_back(newCard);
        }
    }
}

void Deck::shuffle() {
    random_device rd;
    mt19937 gen(rd());
    int n = cards.size();
    for (int i = n - 1; i > 0; i--) {
        int j = gen() % (i + 1);
        std::swap(cards[i], cards[j]);
    }
}

Card Deck::draw() {
    Card topCard = cards.back();
    cards.pop_back();
    return topCard;
}

bool Deck::isEmpty() const {
    return cards.empty();
}

vector<Card> Deck::getCards() const {  
    return cards;
}


