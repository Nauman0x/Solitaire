#pragma once

#include <vector>
#include "Card.h"
using namespace std;

class Deck {
public:
    Deck();
    void shuffle();
    Card draw();
    vector<Card> getCards() const;
    bool isEmpty() const;

private:
    vector<Card> cards;
};

