#include "Game.h"
#include <iostream>
#include <windows.h>
#include <stdio.h>
#include "utility.h"
#include "foundation.h"
#include <thread>
#include <chrono>

Game::Game() {
    tableau.resize(7);
}

void Game::setup() {
    deck.shuffle();
    initializeTableau();
    stockpile = deck.getCards();
}

void Game::initializeTableau() {
    for (int i = 0; i < 7; ++i) {
        for (int j = 0; j <= i; ++j) {
            Card drawnCard = deck.draw();
            if (j == i) {
                drawnCard.setFaceUp(true);
            }
            tableau[i].push_back(drawnCard);
        }
    }
}

bool Game::drawFromWastePile() {
    saveState(foundation, undo_stack);
    const int foundationRow = 6;
    const int tableauStartCol = 30;
    const int drawCardStartCol = tableauStartCol - 6;
    const int drawCardStartRow = foundationRow + 1;

    int cardsToDraw = 0;

    if (initialDisplayCount == 0) {
        if (difficultyLevel == HARD) {
            cardsToDraw = 3;
        }
        else {
            cardsToDraw = 1;
        }
        initialDisplayCount++;
    }
    else {
        if (difficultyLevel == HARD) {
            cardsToDraw = 3;
        }
        else {
            cardsToDraw = 1;
        }
    }

    if (!stockpile.empty()) {
        for (int i = 0; i < cardsToDraw && !stockpile.empty(); ++i) {
            Card drawnCard = stockpile.back();
            stockpile.pop_back();
            drawnCard.setFaceUp(true);
            wastePile.push_back(drawnCard);
        }
        displayWastePile();
        return true;
    }
    return false;
}

void Game::displayWastePile() const {
    const int foundationRow = 6;
    const int tableauStartCol = 30;
    const int wastePileRow = foundationRow + 1;
    const int wasteCardStartCol = tableauStartCol - 6;

    GotoRowCol(wastePileRow - 1, wasteCardStartCol);
    SetColor(0, 7);
    std::cout << "[]";
    SetColor(7, 2);
    if (!wastePile.empty()) {
        for (int i = max(0, (int)wastePile.size() - 3); i < wastePile.size(); ++i) {
            GotoRowCol(wastePileRow + (i - max(0, (int)wastePile.size() - 3)), wasteCardStartCol);
            wastePile[i].display();
        }
    }
}

bool Game::moveDrawnCardToTableau(int tableauIndex) {
    saveState(foundation, undo_stack);
    if (tableauIndex < 0 || tableauIndex >= tableau.size() || wastePile.empty()) {
        return false;
    }
    Card& drawnCard = wastePile.back();
    if (tableau[tableauIndex].empty()) {
        if (drawnCard.getRank() == Rank::King) {
            tableau[tableauIndex].push_back(drawnCard);
            wastePile.pop_back();
            return true;
        }
        else {
            return false;
        }
    }
    Card& topCard = tableau[tableauIndex].back();
    if (drawnCard.isAlternatingColor(topCard) && drawnCard.isOneRankLower(topCard)) {
        tableau[tableauIndex].push_back(drawnCard);
        wastePile.pop_back();
        flipTopCardInTableau(tableauIndex);
        return true;
    }
    return false;
}

void Game::refillStockFromWaste() {
    if (!wastePile.empty()) {
        while (!wastePile.empty()) {
            stockpile.push_back(wastePile.back());
            wastePile.pop_back();
        }
    }
}

void Game::displayTableau() const {
    const int tableauStartRow = 7;
    const int tableauStartCol = 30;
    const int tableauSpacing = 4;
    for (int col = 0; col < 7; ++col) {
        GotoRowCol(tableauStartRow, tableauStartCol + (col * tableauSpacing));
        for (size_t row = 0; row < tableau[col].size(); ++row) {
            GotoRowCol(tableauStartRow + row + 1, tableauStartCol + (col * tableauSpacing));
            tableau[col][row].display();
        }
    }
}

void Game::displayDeck() const {
    const int deckStartRow = 5;
    const int deckStartCol = 30;
    GotoRowCol(deckStartRow, deckStartCol);
    for (const auto& card : deck.getCards()) {
        card.display();
    }
}



bool Game::moveCardBetweenTableau(int fromPile, int toPile) 
{
    saveState(foundation, undo_stack);

    if (fromPile < 0 || fromPile >= tableau.size() || toPile < 0 || toPile >= tableau.size()) {
        return false;  
    }

    if (tableau[fromPile].empty()) {
        return false; 
    }

    int firstFaceUpIndex = -1;
    for (int i = 0; i < tableau[fromPile].size(); ++i) {
        if (tableau[fromPile][i].isFaceUp()) {
            firstFaceUpIndex = i;
            break;
        }
    }

    if (firstFaceUpIndex == -1) {
        return false;  
    }

    Card& cardToMove = tableau[fromPile][firstFaceUpIndex];

    if (tableau[toPile].empty()) {
        if (cardToMove.getRank() == Rank::King) {
            tableau[toPile].insert(tableau[toPile].end(), tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());
            tableau[fromPile].erase(tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());
            flipTopCardInTableau(fromPile); 
            updateScore(10);
            return true;
        }
        else {
            return false;  
        }
    }
    else {
        Card& topCard = tableau[toPile].back();

        if (cardToMove.isAlternatingColor(topCard) && cardToMove.isOneRankLower(topCard)) {
            tableau[toPile].insert(tableau[toPile].end(), tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());
            tableau[fromPile].erase(tableau[fromPile].begin() + firstFaceUpIndex, tableau[fromPile].end());

            flipTopCardInTableau(fromPile);  
            return true;
        }
    }

    return false;  // Move not successful
}

void Game::displayStockpile() const {
    GotoRowCol(1, 0);
    if (stockpile.empty()) {
        std::cout << "Stockpile: Empty" << std::endl;
    }
    else {
        std::cout << "Stockpile: " << stockpile.size() << " cards available." << std::endl;
    }
}

void Game::flipTopCardInTableau(int pileIndex) {
    if (pileIndex >= 0 && pileIndex < tableau.size() && !tableau[pileIndex].empty()) {
        tableau[pileIndex].back().setFaceUp(true);
    }
}

void Game::flipTopCard(int pileIndex) {
    if (pileIndex >= 0 && pileIndex < tableau.size() && !tableau[pileIndex].empty()) {
        tableau[pileIndex].back().setFaceUp(false);
    }
}

int Game::getScore() const {
    return score;
}

void Game::startTimer(int timeLimitInSeconds) {
    timeLimit = timeLimitInSeconds;
    startTime = std::time(nullptr);
}

void Game::checkTimeLimit() {
    time_t currentTime = std::time(nullptr);
    double elapsedTime = std::difftime(currentTime, startTime);
}

void Game::updateScore(int points) {
    score += points;
}


void Game::moveWasteToFoundation(Foundation& foundation, int rpos, int cpos) {
    saveState(foundation,undo_stack);
    if (wastePile.empty()) {
        return;
    }

    Card topWasteCard = wastePile.back(); 
  
    if (rpos != 6) {
        return;
    }

    int suitIndex = -1;
    if (cpos >= 41 && cpos<=44) suitIndex = 0;  
    else if (cpos >= 46 && cpos <= 48) suitIndex = 1;  
    else if (cpos >= 50 && cpos <= 52) suitIndex = 2;  
    else if (cpos >= 54 && cpos <= 56) suitIndex = 3;  

    if (suitIndex != -1) {
        if (foundation.addCard(topWasteCard)) {
            wastePile.pop_back();  
            foundation.displayFoundations();
        }
        
    }
}

void Game::moveTableauToFoundation(Foundation& foundation, int fromPile, int pos, int cpos) {
    saveState(foundation, undo_stack);
    Card& topTableauCard = tableau[fromPile].back();
    int suitIndex = -1;
    if (cpos >= 41 && cpos <= 44) suitIndex = 0;
    else if (cpos >= 46 && cpos <= 48) suitIndex = 1;
    else if (cpos >= 50 && cpos <= 52) suitIndex = 2;
    else if (cpos >= 54 && cpos <= 56) suitIndex = 3;
    if (suitIndex != -1) {
        if (foundation.addCard(topTableauCard)) {
            tableau[fromPile].pop_back();
            flipTopCardInTableau(fromPile);
            foundation.displayFoundations();
            updateScore(10);
        }
    }
   
}

void Game::saveState(Foundation& foundation, std::stack<GameState>& state_stack) {
    GameState currentState = { tableau, foundation, wastePile, score };
    state_stack.push(currentState);
}

bool Game::undoMove(Foundation& foundation) {
    if (undo_stack.empty()) {
        return false;
    }
    saveState(foundation, redo_stack);
    GameState previousState = undo_stack.top();
    undo_stack.pop();
    tableau = previousState.tableau;
    foundation = previousState.foundation;
    wastePile = previousState.wastePile;
    score = previousState.score;
    return true;
}

bool Game::redoMove(Foundation& foundation) {
    if (redo_stack.empty()) {
        return false;
    }
    saveState(foundation, undo_stack);
    GameState nextState = redo_stack.top();
    redo_stack.pop();
    tableau = nextState.tableau;
    foundation = nextState.foundation;
    wastePile = nextState.wastePile;
    score = nextState.score;
    return true;
}

int Game::getRemainingTime() const {
    time_t currentTime = std::time(nullptr);
    double elapsedTime = std::difftime(currentTime, startTime);
    return max(0, timeLimit - static_cast<int>(elapsedTime));
}

void DrawButton() {

    GotoRowCol(4, 28);
    SetColor(0, 7);
    std::cout << "Solitaire";
    GotoRowCol(6, 28);
    SetColor(0, 7);
    std::cout << "Play Game";
    SetColor(7, 0);

}



int main() {
    Game game;
    Foundation foundation;
    int timeLimit = 1000;
    game.startTimer(timeLimit);
    time_t lastUpdateTime = std::time(nullptr);
        int remainingTime = game.getRemainingTime();

    DrawButton();
    int rpos, cpos;
    GetRowColbyClick(rpos, cpos);
    if (rpos == 6) {
        system("cls");
        GotoRowCol(5, 25);
        SetColor(0, 7);
        std::cout << "Easy";
        GotoRowCol(5, 35);
        std::cout << "Hard";
        SetColor(7, 2);
    }
    bool selection = false;
    bool deduction = false;
    GetRowColbyClick(rpos, cpos);
    if (cpos >= 25 && cpos <= 28) {
        system("cls");
        game.difficultyLevel = Game::EASY;
        selection = true;
    }
    else if (cpos >= 35 && cpos <= 38) {
        system("cls");
        game.difficultyLevel = Game::HARD;
        selection = true;
        deduction = true;
    }
    game.setup();
    if (selection == true) {
        GotoRowCol(4, 4);
        SetColor(0, 2);
        cout << "Score: " << game.getScore() << "\n";
        GotoRowCol(5, 4);
        cout << "Time: " << remainingTime << " seconds" << std::endl;
        SetColor(7, 2);

        SetColor(7, 2);
        foundation.displayFoundations();
        game.displayTableau();
        game.displayWastePile();
    }
    int fromPile = -1, toPile = -1;
    bool wastePileSelected = false;
    bool tableauSelected = false;
   
    while (true) {
        remainingTime = game.getRemainingTime();
        GetRowColbyClick(rpos, cpos);
        if (rpos == 6 && cpos >= 24 && cpos <= 25) {
            if (game.stockpile.empty()) {
                if (!game.wastePile.empty()) {
                    game.refillStockFromWaste();
                    if (deduction) game.updateScore(-10);
                    system("cls");
                    game.displayWastePile();
                }
            }
            else {
                if (game.drawFromWastePile()) {
                    system("cls");
                    game.displayWastePile();
                }
            }
        }
        if (rpos >= 7 && rpos <= 9 && cpos >= 24 && cpos <= 25 && !wastePileSelected) {
            if (!game.wastePile.empty()) {
                wastePileSelected = true;
            }
        }
        if (wastePileSelected && rpos == 6) {
            game.moveWasteToFoundation(foundation, rpos, cpos);
            system("cls");
            wastePileSelected = false;
            game.updateScore(10);
        }
        else if (wastePileSelected && rpos >= 7) {
            toPile = (cpos - 30) / 4;
            if (toPile >= 0 && toPile < 7 && game.moveDrawnCardToTableau(toPile)) {
                system("cls");
                game.updateScore(5);
                wastePileSelected = false;
            }
        }
        if (rpos >= 8 && rpos <= 14) {
            toPile = (cpos - 30) / 4;
            if (toPile >= 0 && toPile < 7) {
                if (fromPile == -1) {
                    fromPile = toPile;
                    tableauSelected = true;
                }
                else {
                    if (game.moveCardBetweenTableau(fromPile, toPile)) {
                        system("cls");
                        game.updateScore(5);
                    }
                    fromPile = -1;
                    tableauSelected = false;
                }
            }
        }
        if (tableauSelected && rpos == 6) {
            game.moveTableauToFoundation(foundation, fromPile, rpos, cpos);
            system("cls");
            tableauSelected = false;
            game.updateScore(10);
        }
        if (GetAsyncKeyState(VK_RBUTTON)) {
            std::cout << "Exiting game.\n";
            break;
        }
        if (rpos == 12 && cpos >= 4 && cpos <= 7) {
            game.undoMove(foundation);
            system("cls");
        }
        if (rpos == 14 && cpos >= 4 && cpos <= 7) {
            game.redoMove(foundation);
            system("cls");
        }
        GotoRowCol(5, 4);
        SetColor(0, 2);
        std::cout << "                     " << std::endl;
        SetColor(7, 2);
        GotoRowCol(5, 4);
        SetColor(0, 2);
        std::cout << "Time: " << remainingTime << " seconds" << std::endl;
        SetColor(7, 2);

        //system("cls");
        foundation.displayFoundations();
        game.displayTableau();
        game.displayWastePile();
        GotoRowCol(4, 4);
        SetColor(0, 2);
        cout << "Score: " << game.getScore() << "\n";
        SetColor(7, 2);

        game.checkTimeLimit();
        GotoRowCol(12, 4);
        SetColor(0, 7);
        std::cout << "Undo";
        GotoRowCol(14, 4);
        std::cout << "Redo";
        SetColor(7, 2);
        if (foundation.isGameWon()) {
            GotoRowCol(14, 25);
            std::cout << "Congratulations! You've won the game.\n";
            break;
        }
        if (remainingTime <= 0) {
            GotoRowCol(14, 25);
            std::cout << "Time's up! Game over!" << std::endl;
            break;
        }
        //std::cout << rpos << " " << cpos << std::endl;
    }
    return 0;
}
