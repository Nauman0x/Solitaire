#pragma once

enum class Suit { Hearts, Diamonds, Clubs, Spades };
enum class Rank { Ace = 1, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King };

class Card {
public:
    Card();
    Card(Rank rank, Suit suit, bool faceUp = false);
    Rank getRank() const;
    Suit getSuit() const;
    bool isFaceUp() const;
    void setFaceUp(bool isFaceUp);
    bool isAlternatingColor(const Card& other) const;
    bool isOneRankLower(const Card& other) const;
    bool isOneRankHigher(const Card& other) const;
    void display() const;
    Suit suit;
    Rank rank;
    bool faceUp;  // Whether the card is face-up or face-down

private:
};

