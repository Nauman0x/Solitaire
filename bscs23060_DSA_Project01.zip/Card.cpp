﻿#include "Card.h"
#include <iostream>
#include <stdio.h>
#include <windows.h>
#include<utility>
using namespace std;


Card::Card() : rank(Rank::Ace), suit(Suit::Hearts), faceUp(false) {
}

Card::Card(Rank rank, Suit suit, bool faceUp) : rank(rank), suit(suit), faceUp(faceUp) {}

Rank Card::getRank() const {
    return rank;
}

Suit Card::getSuit() const {
    return suit;
}

bool Card::isFaceUp() const {
    return faceUp;
}

void Card::setFaceUp(bool isFaceUp) {
    faceUp = isFaceUp;
}

bool Card::isAlternatingColor(const Card& other) const {
    bool thisIsRed = (suit == Suit::Hearts || suit == Suit::Diamonds);
    bool otherIsRed = (other.suit == Suit::Hearts || other.suit == Suit::Diamonds);
    return thisIsRed != otherIsRed; 
}

bool Card::isOneRankLower(const Card& other) const {
    return static_cast<int>(rank) + 1 == static_cast<int>(other.rank);
}

bool Card::isOneRankHigher(const Card& other) const {
    return static_cast<int>(rank) == static_cast<int>(other.getRank()) + 1;
}


void setColor(int tcl, int bcl)
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), (tcl + (bcl * 16)));
}

void Card::display() const {
    string rankStr;
    switch (rank) {
    case Rank::Ace: rankStr = "A"; break;
    case Rank::Two: rankStr = "2"; break;
    case Rank::Three: rankStr = "3"; break;
    case Rank::Four: rankStr = "4"; break;
    case Rank::Five: rankStr = "5"; break;
    case Rank::Six: rankStr = "6"; break;
    case Rank::Seven: rankStr = "7"; break;
    case Rank::Eight: rankStr = "8"; break;
    case Rank::Nine: rankStr = "9"; break;
    case Rank::Ten: rankStr = "10"; break;
    case Rank::Jack: rankStr = "J"; break;
    case Rank::Queen: rankStr = "Q"; break;
    case Rank::King: rankStr = "K"; break;
    }

    if (faceUp) {
        int textColor, backgroundColor;

        switch (suit) {
        case Suit::Hearts:
        case Suit::Diamonds:
            textColor = 4;  
            backgroundColor = 15; 
            break;
        case Suit::Clubs:
        case Suit::Spades:
            textColor = 0;  
            backgroundColor = 15;
            break;
        }

        setColor(textColor, backgroundColor);

        cout << rankStr;
        if (suit == Suit::Hearts) {
            printf("%c",3); // Heart symbol
        }
        else if (suit == Suit::Diamonds) {
            printf("%c", 4); // Diamond symbol
        }
        else if (suit == Suit::Clubs) {
            printf("%c", 5); // Club symbol
        }
        else if (suit == Suit::Spades) {
            printf("%c", 6); // Spade symbol
        }

      
    }
    else {
        setColor(0, 7);
        cout << "[]";  // Face-down card display
    }
    setColor(7, 2);
    cout << endl;
}
