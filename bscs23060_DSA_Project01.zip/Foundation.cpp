#include "foundation.h"
#include <iostream>

Foundation::Foundation() {
    // Initialize each foundation stack as empty
    for (int i = 0; i < 4; ++i) {
        foundationStacks[i] = std::vector<Card>();
    }
}
// Copy constructor
Foundation::Foundation(const Foundation& other) {
    for (int i = 0; i < 4; ++i) {
        foundationStacks[i] = other.foundationStacks[i]; // Copy each foundation stack
    }
}

// Copy assignment operator
Foundation& Foundation :: operator=(const Foundation& other) {
    if (this != &other) {
        for (int i = 0; i < 4; ++i) {
            foundationStacks[i] = other.foundationStacks[i];
        }
    }
    return *this;
}


bool Foundation::addCard(const Card& card) {
    int suitIndex = static_cast<int>(card.getSuit());

    if (suitIndex < 0 || suitIndex >= 4) {
        return false;  // Invalid suit index
    }

    // Check if the foundation stack for the suit is empty
    if (foundationStacks[suitIndex].empty()) {
        // Only an Ace can be added to an empty foundation
        if (card.getRank() == Rank::Ace) {
            foundationStacks[suitIndex].push_back(card);
            return true;  // Successfully added
        }
        return false;  // Invalid move: cannot add a non-Ace to an empty foundation
    }
    else {
        // Get the top card of the foundation stack
        Card& topCard = foundationStacks[suitIndex].back();

        // Check if the card can be placed on top of the foundation stack
        if (card.isOneRankHigher(topCard) && card.getSuit() == topCard.getSuit()) {
            foundationStacks[suitIndex].push_back(card);
            return true;  // Successfully added
        }
        return false;  // Invalid move: card is not one rank higher or of a different suit
    }
}


void RowCol(int rpos, int cpos)
{
    COORD scrn;
    HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
    scrn.X = cpos;
    scrn.Y = rpos;
    SetConsoleCursorPosition(hOuput, scrn);
}
void SetClr(int tcl, int bcl)
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), (tcl + (bcl * 16)));
}

void Foundation::displayFoundations() const {
    const int foundationStartRow = 6;   // Row for foundation
    const int foundationStartCol = 42;     // Starting column for tableau
    const int foundationSpacing = 4;
    if (!foundationStacks[0].empty())
    {
        RowCol(foundationStartRow, foundationStartCol );
        const Card& topCard = foundationStacks[0].back();
        topCard.display();  // Display top card
    }
    else {
        RowCol(foundationStartRow, foundationStartCol);
        SetClr(4, 15);
        cout << "[";
        printf("%c", 3);
        cout << "]";
        SetClr(7, 2);
    }
    if (!foundationStacks[1].empty())
    {
        RowCol(foundationStartRow, foundationStartCol+4);
        const Card& topCard = foundationStacks[1].back();
        topCard.display();  // Display top card
        SetClr(7, 2);
    }
    else {
        RowCol(foundationStartRow, foundationStartCol + 4);
        SetClr(4, 15);
        cout << "[";
        printf("%c", 4);
        cout << "]";
        SetClr(7, 2);
    }
    if (!foundationStacks[2].empty())
    {
        RowCol(foundationStartRow, foundationStartCol+8);
        const Card& topCard = foundationStacks[2].back();
        topCard.display();  // Display top card
        SetClr(7, 2);

    }
    else {
        RowCol(foundationStartRow, foundationStartCol + 8);
        SetClr(0, 15);
        cout << "[";
        printf("%c", 5);
        cout << "]";
        SetClr(7, 2);

       
    }
    if (!foundationStacks[3].empty())
    {
        RowCol(foundationStartRow, foundationStartCol+12);
        const Card& topCard = foundationStacks[3].back();
        topCard.display();  // Display top card
        SetClr(7, 2);
    }
    else {
        RowCol(foundationStartRow, foundationStartCol + 12);
        SetClr(0, 15);
        cout << "[";
        printf("%c", 6);
        cout << "]";
        SetClr(7, 2);
    }
  
}

bool Foundation::isComplete(int index) const {
    return foundationStacks[index].size() == 13; 
}

bool Foundation::isGameWon() const {
    for (int i = 0; i < 4; ++i) {
        if (!isComplete(i)) {
            return false; 
        }
    }
    return true;  
}

bool Foundation::isEmpty(int index) const {
    return foundationStacks[index].empty();
}
