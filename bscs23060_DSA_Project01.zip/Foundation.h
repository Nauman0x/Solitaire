#pragma once

#include <vector>
#include "Card.h" 
#include <windows.h>
using namespace std;

class Foundation {
private:
    std::vector<Card> foundationStacks[4];

public:
    Foundation();
    Foundation(const Foundation& other); 
    Foundation& operator=(const Foundation& other); 
    bool addCard(const Card& card);
    void displayFoundations() const;
    bool isComplete(int index) const;
    bool isEmpty(int index) const;
    bool isGameWon() const;
};

