#pragma once
#include <vector>
#include <stack>
#include <ctime>
#include "Card.h"
#include "Deck.h"
#include "Foundation.h"
using namespace std;
enum DifficultyLevel {
    EASY,
    HARD
};

struct GameState {
    std::vector<std::vector<Card>> tableau;
    Foundation foundation;
    std::vector<Card> wastePile;
    int score;
};

class Game {
public:
    Game();
    enum Difficulty { EASY, HARD };
    Difficulty difficultyLevel;
    vector<Card> wastePile;
    vector<vector<Card>> tableau;
    Foundation foundation;
    vector<Card> stockpile;
    std::vector<Card> drawnCards;
    void setup();
    void displayTableau() const;
    void displayDeck() const;
    void displayStockpile() const;
    int initialDisplayCount = 0;
    bool moveCardBetweenTableau(int fromPile, int toPile);
    void moveWasteToFoundation(Foundation& foundation, int n1, int n2);
    bool drawFromWastePile();
    void displayWastePile() const;
    bool moveDrawnCardToTableau(int tableauIndex);
    void flipTopCardInTableau(int pileIndex);
    void flipTopCard(int pileIndex);
    void moveTableauToFoundation(Foundation& foundation, int fromPile, int n1, int n2);
    bool undoMove(Foundation& foundation);
    bool redoMove(Foundation& foundation);
    int getRemainingTime() const;
    void checkGameWon();
    void startTimer(int timeLimitInSeconds);
    void checkTimeLimit();
    void updateScore(int points);
    int getScore() const;
    void refillStockFromWaste();
 
 

private:
    Deck deck;
    stack<GameState> undo_stack;
    stack<GameState> redo_stack;
    void saveState(Foundation& foundation, stack<GameState>& state_stack);
    int score;
    time_t startTime;

    int timeLimit;
    bool gameWon = false;
    void initializeTableau();
  
};

